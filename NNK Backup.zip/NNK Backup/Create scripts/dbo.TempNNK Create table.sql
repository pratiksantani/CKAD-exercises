USE [Verivox]
GO

/****** Object:  Table [dbo].[TempNNK]    Script Date: 18.03.2024 15:12:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TempNNK](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Serialnummer] [nvarchar](50) NULL,
	[Ablesedatum] [nvarchar](10) NULL,
	[Tariftyp] [nvarchar](10) NULL,
	[Anlage] [nvarchar](30) NULL,
	[Verbrauchstelle] [nvarchar](10) NULL,
	[Ablesehinweis] [nvarchar](5) NULL,
	[LastReadDate] [nvarchar](20) NULL,
	[MarktLokationsID] [nvarchar](200) NULL,
	[DruckBelegnummer] [nvarchar](200) NULL,
	[NoOfPriceAnpassungen] [int] NULL
) ON [PRIMARY]
GO

