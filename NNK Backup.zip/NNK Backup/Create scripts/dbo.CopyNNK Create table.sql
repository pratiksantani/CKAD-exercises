USE [Verivox]
GO

/****** Object:  Table [dbo].[CopyNNK]    Script Date: 18.03.2024 15:12:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CopyNNK](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Serialnummer] [nvarchar](2000) NOT NULL,
	[Ablesedatum] [nvarchar](2000) NOT NULL,
	[Tariftyp] [nvarchar](10) NULL,
	[Anlage] [nvarchar](30) NULL,
	[Verbrauchstelle] [nvarchar](10) NULL,
	[Ablesehinweis] [nvarchar](5) NULL,
	[LastReadDate] [nvarchar](20) NULL,
	[MarktLokationsID] [nvarchar](200) NULL,
	[DruckBelegnummer] [nvarchar](200) NULL,
	[NoOfPriceAnpassungen] [int] NULL,
	[Status_Bot2] [nvarchar](1) NULL,
	[Status_Bot3] [nvarchar](1) NULL,
	[Status_Bot4] [nvarchar](1) NULL,
	[ErrorComment] [nvarchar](500) NULL,
	[CreatedDate] [date] NULL,
	[LastUpdatedDate] [date] NULL,
	[Ableseeinheit] [nvarchar](30) NULL
) ON [PRIMARY]
GO

