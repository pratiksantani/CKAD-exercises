USE [Verivox]
GO

/****** Object:  Table [dbo].[NNK]    Script Date: 18.03.2024 15:13:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[NNK](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Serialnummer] [nvarchar](2000) NOT NULL,
	[Ablesedatum] [nvarchar](2000) NOT NULL,
	[Tariftyp] [nvarchar](10) NULL,
	[Anlage] [nvarchar](30) NULL,
	[Verbrauchstelle] [nvarchar](10) NULL,
	[Ablesehinweis] [nvarchar](5) NULL,
	[LastReadDate] [nvarchar](20) NULL,
	[MarktLokationsID] [nvarchar](200) NULL,
	[DruckBelegnummer] [nvarchar](200) NULL,
	[NoOfPriceAnpassungen] [int] NULL,
	[Status_Bot2] [nvarchar](1) NULL,
	[Status_Bot3] [nvarchar](1) NULL,
	[Status_Bot4] [nvarchar](1) NULL,
	[ErrorComment] [nvarchar](500) NULL,
	[CreatedDate] [date] NULL,
	[LastUpdatedDate] [datetime] NULL,
	[Ableseeinheit] [nvarchar](30) NULL,
 CONSTRAINT [PK_SN] PRIMARY KEY CLUSTERED 
(
	[Serialnummer] ASC,
	[Ablesedatum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

