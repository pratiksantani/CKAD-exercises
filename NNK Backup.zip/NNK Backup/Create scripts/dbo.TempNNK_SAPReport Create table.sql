USE [Verivox]
GO

/****** Object:  Table [dbo].[TempNNK_SAPReport]    Script Date: 18.03.2024 15:13:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TempNNK_SAPReport](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Ableseeinheit] [nvarchar](50) NULL,
	[Ablesedatum] [nvarchar](20) NULL,
	[Verbrauchstelle] [nvarchar](100) NULL,
	[AG] [nvarchar](2) NULL,
	[AA] [nvarchar](2) NULL,
	[Serialnummer] [nvarchar](200) NULL,
	[Zaehlerstand] [nvarchar](100) NULL,
	[Anlage] [nvarchar](300) NULL,
	[Tariftyp] [nvarchar](100) NULL,
	[AblesedatumVonEl27] [nvarchar](50) NULL,
	[Ablesenummer] [nvarchar](2000) NULL,
	[Ablesehinweis] [nvarchar](20) NULL,
	[Portion] [nvarchar](20) NULL,
	[PreisAnpassung] [nvarchar](10) NULL,
	[ZEM] [nvarchar](10) NULL
) ON [PRIMARY]
GO

