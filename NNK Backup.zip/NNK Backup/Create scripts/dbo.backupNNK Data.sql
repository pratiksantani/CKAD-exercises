USE [Verivox]
GO

INSERT INTO [dbo].[backupNNK]
           ([Serialnummer]
           ,[Ablesedatum]
           ,[Tariftyp]
           ,[Anlage]
           ,[Verbrauchstelle]
           ,[Ablesehinweis]
           ,[LastReadDate]
           ,[MarktLokationsID]
           ,[DruckBelegnummer]
           ,[NoOfPriceAnpassungen]
           ,[Status_Bot2]
           ,[Status_Bot3]
           ,[Status_Bot4]
           ,[ErrorComment]
           ,[CreatedDate]
           ,[LastUpdatedDate]
           ,[Ableseeinheit])
     VALUES
           (<Serialnummer, nvarchar(2000),>
           ,<Ablesedatum, nvarchar(2000),>
           ,<Tariftyp, nvarchar(10),>
           ,<Anlage, nvarchar(30),>
           ,<Verbrauchstelle, nvarchar(10),>
           ,<Ablesehinweis, nvarchar(5),>
           ,<LastReadDate, nvarchar(20),>
           ,<MarktLokationsID, nvarchar(200),>
           ,<DruckBelegnummer, nvarchar(200),>
           ,<NoOfPriceAnpassungen, int,>
           ,<Status_Bot2, nvarchar(1),>
           ,<Status_Bot3, nvarchar(1),>
           ,<Status_Bot4, nvarchar(1),>
           ,<ErrorComment, nvarchar(500),>
           ,<CreatedDate, date,>
           ,<LastUpdatedDate, date,>
           ,<Ableseeinheit, nvarchar(30),>)
GO

