USE [Verivox]
GO
/****** Object:  StoredProcedure [dbo].[DELTALOAD_NNK]    Script Date: 18.03.2024 15:19:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kiru
-- Create date: 19.01.2022
-- Description:	Procedure to load delta cases from SAP report to NNK table
-- =============================================
ALTER   PROCEDURE [dbo].[DELTALOAD_NNK] 

	@csvFilePath NVARCHAR(2000), -- CSV file path of SAP report
	@status INT OUTPUT, -- execution status
	@ERROR NVARCHAR(2000) OUTPUT -- error message if any
AS
BEGIN
SET NOCOUNT ON;

declare @SQL NVARCHAR(2000)
declare @SNo NVARCHAR(2000)


SET @status = 0
SET @ERROR = ''




BEGIN TRY

		
		--clear temp table
		Delete from TempNNK_SAPReport

		--Bulk insert
		
		SET @SQL = 'BULK INSERT TempNNK_SAPReport FROM '''+@csvFilePath+''' WITH (FIRSTROW = 2,FIELDTERMINATOR = '';'',  ROWTERMINATOR = ''\n'' )'
		PRINT(@SQL)
		EXEC(@SQL)

		

		Update TempNNK_SAPReport SET AblesedatumVonEl27 =  CONVERT(NVARCHAR(30),CONVERT(DATE,dateadd(d,CONVERT(INT,AblesedatumVonEl27),'1899-12-30')))

		Update TempNNK_SAPReport SET Ablesedatum =  CONVERT(NVARCHAR(30),CONVERT(DATE,dateadd(d,CONVERT(INT,Ablesedatum),'1899-12-30')))

		PRINT('select start')

		--create a temporary working table 

		Select [Ableseeinheit],[Verbrauchstelle],[Ablesedatum],[Serialnummer],[Tariftyp],[Anlage],[Ablesehinweis],[Portion],[PreisAnpassung],[ZEM],[AblesedatumVonEl27] into #myTempTable from TempNNK_SAPReport

	  	PRINT('select end')
	
		--clear working area

		Delete from #myTempTable
		 
		PRINT('delete end')

		--find and delete delta

		--step 1. Add unique serialnummers not already in db

		INSERT INTO #myTempTable 
			SELECT [Ableseeinheit],[Verbrauchstelle],[Ablesedatum], [Serialnummer],[Tariftyp],[Anlage],[Ablesehinweis],[Portion],[PreisAnpassung],[ZEM],[AblesedatumVonEl27] from TempNNK_SAPReport where Serialnummer NOT IN (SELECT Serialnummer from NNK)

		PRINT('first insert end')

		--step 2. Delete overlapping serialnummers with same ablesdatum

		--DELETE FROM TempNNK_SAPReport where id IN (SELECT a.id from NNK a inner join TempNNK_SAPReport b on a.Serialnummer = b.Serialnummer and a.Ablesedatum = b.AblesedatumVonEl27 )

		 DELETE FROM TempNNK_SAPReport where Serialnummer  IN (SELECT a.Serialnummer from NNK a inner join TempNNK_SAPReport b on a.Serialnummer = b.Serialnummer and a.Ablesedatum = b.AblesedatumVonEl27 )

		--step3.1. Join the remaining TempNNK_SAPReport and NNK based on only Serialnummer and filter ones processed

		INSERT INTO #myTempTable SELECT b.[Ableseeinheit],b.[Verbrauchstelle],b.[Ablesedatum], b.[Serialnummer],b.[Tariftyp],b.[Anlage],b.[Ablesehinweis],b.[Portion],b.[PreisAnpassung],b.[ZEM],b.[AblesedatumVonEl27] from NNK a inner join TempNNK_SAPReport b on a.Serialnummer = b.Serialnummer and a.Status_Bot2 != 'R'

		PRINT('second insert end')

		--step3.2. Join the remaining TempNNK_SAPReport and NNK based on only Serialnummer and filter ones not already processed

		UPDATE NNK SET Ablesedatum = b.Ablesedatum,LastReadDate = b.AblesedatumVonEl27,NoOfPriceAnpassungen = b.PreisAnpassung,LastUpdatedDate = GETDATE()  from  NNK a inner join TempNNK_SAPReport b on a.Serialnummer = b.Serialnummer and a.Status_Bot2 = 'R'

		PRINT('insert  start')
		
		--load to main table
           	
		INSERT INTO NNK ([Serialnummer]
						,[Verbrauchstelle]
						,[Ablesedatum]
						,[Tariftyp]
						,[Anlage]
						,[Ablesehinweis]
						,[NoOfPriceAnpassungen]
						,[CreatedDate]
						,[LastUpdatedDate]
						,[Ableseeinheit]
						,[LastReadDate]
						,Status_Bot2
						,Status_Bot3
						,Status_Bot4)

		SELECT	  [Serialnummer] 
				 ,[Verbrauchstelle]
				  ,[AblesedatumVonEl27]
				  ,[Tariftyp]
				  ,[Anlage]	  
				  ,[ZEM]
				  ,[PreisAnpassung]
				  ,GETDATE()
				  ,GETDATE()
				  ,[Ableseeinheit]
				  ,[Ablesedatum]
				  ,'R'
				  ,'P'
				  ,'P'
			

		FROM #myTempTable
 	
	PRINT('insert  end')
END TRY

BEGIN CATCH
       
		PRINT(CONCAT(ERROR_MESSAGE(),'  ',ERROR_SEVERITY(),'  ',ERROR_STATE()))
		SET @ERROR = CONCAT(ERROR_MESSAGE(),'  ',ERROR_SEVERITY(),'  ',ERROR_STATE())
		SET @status = 1

END CATCH

END
